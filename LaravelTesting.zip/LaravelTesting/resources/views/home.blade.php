<!DOCTYPE html>
<html>
<head>
    <title>Proyek Laravel Sederhana</title>
</head>
<body>
    <h1>Selamat datang di proyek Laravel sederhana!</h1>
    <form method="POST" action="/submit">
        @csrf
        <input type="text" name="name" placeholder="Nama Anda">
        <button type="submit">Kirim</button>
    </form>
</body>
</html>
