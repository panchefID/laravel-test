<!DOCTYPE html>
<html>
<head>
    <title>Proyek Laravel Sederhana</title>
</head>
<body>
    <h1>Hasil Pengiriman Formulir</h1>
    <p>Halo, {{ $name }}!</p>
</body>
</html>
