<!DOCTYPE html>
<html>
<head>
    <title>Proyek Laravel Sederhana</title>
</head>
<body>
    <h1>Hasil Pengiriman Formulir</h1>
    <p>Halo, <?php echo e($name); ?>!</p>
</body>
</html>
<?php /**PATH C:\Users\Qompac PC\Desktop\Kodingan\nama-proyek\resources\views/result.blade.php ENDPATH**/ ?>