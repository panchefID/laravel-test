<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class HomeTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Test untuk halaman utama.
     *
     * @return void
     */
    public function testHomePage()
    {
        $response = $this->get('/');

        $response->assertStatus(200);
        $response->assertSeeText('Selamat datang di proyek Laravel sederhana!');
    }

    /**
     * Test untuk pengiriman formulir.
     *
     * @return void
     */
    public function testFormSubmission()
    {
        $response = $this->post('/submit', ['name' => 'John Doe']);

        $response->assertStatus(200);
        $response->assertSeeText('Hasil Pengiriman Formulir');
        $response->assertSeeText('Halo, John Doe!');
    }
}
